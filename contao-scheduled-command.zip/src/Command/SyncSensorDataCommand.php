<?php

namespace PbdKn\ContaoContaohabBundle\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class SyncSensorDataCommand extends Command
{
    protected static \$defaultName = 'pbdkn:sync-sensor-data';

    protected function execute(InputInterface \$input, OutputInterface \$output): int
    {
        \$logDir = __DIR__ . '/../../../../var/log';
        if (!is_dir(\$logDir)) {
            mkdir(\$logDir, 0777, true);
        }

        \$msg = "[" . date('c') . "] SyncSensorDataCommand executed\n";
        file_put_contents(\$logDir . '/sync-test.txt', \$msg, FILE_APPEND);

        return Command::SUCCESS;
    }
}
