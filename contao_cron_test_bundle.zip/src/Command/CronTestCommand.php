<?php

namespace ContaoCronTestBundle\Command;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

#[AsCommand(
    name: 'cron:test',
    description: 'Test scheduled command for contao:cron'
)]
class CronTestCommand extends Command
{
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        file_put_contents(TL_ROOT . '/var/log/cron_test_output.log', date('Y-m-d H:i:s') . " - cron:test executed\n", FILE_APPEND);
        return Command::SUCCESS;
    }
}
