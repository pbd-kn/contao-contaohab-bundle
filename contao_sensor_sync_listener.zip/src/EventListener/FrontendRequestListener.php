<?php

namespace PbdKn\ContaoContaohabBundle\EventListener;

use Contao\CoreBundle\Framework\ContaoFramework;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Output\NullOutput;
use Symfony\Bundle\FrameworkBundle\Console\Application;

class FrontendRequestListener
{
    public function __construct(
        private ContaoFramework $framework,
    ) {}

    public function onKernelRequest(RequestEvent $event): void
    {
        if (!$event->isMainRequest()) {
            return;
        }

        $request = $event->getRequest();
        if (!str_starts_with($request->getPathInfo(), '/')) {
            return;
        }

        // Optional: Nur alle 5 Minuten
        $lastRunFile = __DIR__ . '/../../var/sensor_sync_last.txt';
        if (file_exists($lastRunFile) && (time() - filemtime($lastRunFile)) < 300) {
            return;
        }
        @touch($lastRunFile);

        $kernel = $event->getKernel();
        $app = new Application($kernel);
        $app->setAutoExit(false);

        $input = new ArrayInput([
            'command' => 'pbdkn:sync-sensor-data',
        ]);

        $output = new NullOutput();

        try {
            $app->run($input, $output);
        } catch (\Throwable $e) {
            // Fehlerbehandlung oder Logging möglich
        }
    }
}
