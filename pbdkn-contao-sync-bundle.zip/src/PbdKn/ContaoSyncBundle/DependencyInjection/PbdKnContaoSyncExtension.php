<?php

namespace PbdKn\ContaoSyncBundle\DependencyInjection;

use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Extension\Extension;

class PbdKnContaoSyncExtension extends Extension
{
    public function load(array $configs, ContainerBuilder $container): void
    {
    }
}
