<?php

namespace PbdKn\ContaoSyncBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PbdKnContaoSyncBundle extends Bundle
{
}
