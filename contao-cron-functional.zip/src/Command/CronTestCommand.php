<?php

namespace App\Command;

use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

#[AsCommand(
    name: 'app:cron-test',
    description: 'Test cron command that writes to a log file.'
)]
class CronTestCommand extends Command
{
    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $logFile = __DIR__ . '/../../../var/log/cron-test.log';
        if (!is_dir(dirname($logFile))) {
            mkdir(dirname($logFile), 0777, true);
        }
        file_put_contents($logFile, "[" . date('c') . "] Command executed\n", FILE_APPEND);
        return Command::SUCCESS;
    }
}
