<?php

namespace PbdKn\ContaoContaohabBundle\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class SyncSensorDataCommand extends Command
{
    protected static $defaultName = 'pbdkn-sync-sensor-data';

    public function __invoke(): int
    {
        file_put_contents(__DIR__ . '/../../../var/log/sync-test.txt', "[".date('c')."] __invoke() called\n", FILE_APPEND);
        return Command::SUCCESS;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        file_put_contents(__DIR__ . '/../../../var/log/sync-test.txt', "[".date('c')."] execute() called\n", FILE_APPEND);
        return Command::SUCCESS;
    }
}
